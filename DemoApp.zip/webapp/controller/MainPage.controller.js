sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller,JSONModel) {
	"use strict";

	return Controller.extend("com.sap.demoDemoApp.controller.MainPage", {
		onInit: function() {
		this.getView().byId("idSDtab").setVisible(false);
		this.getView().byId("idMM1tab").setVisible(false);
		var OdataSD = [{"EXITNAME":"SD01","WERKS":"ATA0","ACTIVE":""},
					{"EXITNAME":"SD01","WERKS":"DEA0","ACTIVE":"X"},
					{"EXITNAME":"SD01","WERKS":"DEB0","ACTIVE":""},
					{"EXITNAME":"SD01","WERKS":"PL00","ACTIVE":""},
					{"EXITNAME":"SD01","WERKS":"Lyle","ACTIVE":"X"}];
					
					 var oModelSD = new sap.ui.model.json.JSONModel(OdataSD);
                 sap.ui.getCore().setModel(oModelSD, "SDModelData");
                 this.getView().setModel(oModelSD, "SDModelData");
                 var OdataMM =[{"EXITNAME":"MM12","VKORG":"ATA0","AUART":"ZAGW","ACTIVE":""},
					{"EXITNAME":"MM12","VKORG":"ATA0","AUART":"ZCRE","ACTIVE":"X"},
					{"EXITNAME":"MM12","VKORG":"CZA0","AUART":"YOFF","ACTIVE":"X"},
					{"EXITNAME":"MM12","VKORG":"DEA0","AUART":"ZAGW","ACTIVE":"X"},
					{"EXITNAME":"MM12","VKORG":"DEA0","AUART":"ZCRE","ACTIVE":"X"},
					{"EXITNAME":"MM12","VKORG":"DEB0","AUART":"ZAGW","ACTIVE":"X"}];
					var oModelMM = new sap.ui.model.json.JSONModel(OdataMM);
                 sap.ui.getCore().setModel(oModelMM, "MMModelData");
                 this.getView().setModel(oModelMM, "MMModelData");

		        },
		onPress : function(oEvent){
			debugger 
			if(this.getView().byId("idAppSelect").getSelectedKey()==="SD"){
				this.getView().byId("idSDtab").setVisible(true);
					this.getView().byId("idMM1tab").setVisible(false);
			}else{
				this.getView().byId("idMM1tab").setVisible(true);
					this.getView().byId("idSDtab").setVisible(false);
			}
			
		}
	});
});